 pip install git+https://github.com/giladoo/jdatetimext.git --break-system-packages

1.0.8
datetime_pattern() added to prevent false on date pattern mismatch.