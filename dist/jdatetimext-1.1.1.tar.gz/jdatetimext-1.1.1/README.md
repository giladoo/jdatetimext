 pip install git+https://github.com/giladoo/jdatetimext.git --break-system-packages

1.1.1
datetime_pattern() added to prevent false on date pattern mismatch.