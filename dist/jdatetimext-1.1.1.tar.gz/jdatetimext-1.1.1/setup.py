import sys
from setuptools import setup, Extension

setup(
    install_requires=["jdatetime>=5.0",],

    entry_points="""
[console_scripts]

""",
)